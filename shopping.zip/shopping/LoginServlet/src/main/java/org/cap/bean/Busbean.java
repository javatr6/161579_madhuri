package org.cap.bean;

public class Busbean {

}
