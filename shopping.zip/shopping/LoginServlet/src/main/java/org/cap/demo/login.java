package org.cap.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.bean.loginbean;
import org.cap.service.InterserviceLogin;
import org.cap.service.IserviceLogin;

@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
   

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter pw = response.getWriter();
		String username = request.getParameter("userName");
		String password = request.getParameter("userPwd");
		loginbean loginBean=new loginbean(username,password);
		InterserviceLogin loginService = new IserviceLogin();
		if(loginService.checkUser(loginBean)) {
			response.sendRedirect("pages/logged.html");
		}
		else {
			
			pw.println("You have entered wrong username or password");
            RequestDispatcher rd=request.getRequestDispatcher("index.html");
            rd.include(request, response);    
		}
	}
}
		
	

