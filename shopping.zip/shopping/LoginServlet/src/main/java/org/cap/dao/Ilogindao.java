package org.cap.dao;



import org.cap.bean.loginbean;

public interface Ilogindao {
	
	

	public boolean isValidLogin(loginbean loginBean);
	public abstract boolean checkUser(loginbean loginBean);


}
