package org.cap.service;



import org.cap.bean.loginbean;
import org.cap.dao.Ilogindao;
import org.cap.dao.logindao;


public class IserviceLogin implements InterserviceLogin {
	logindao loginDAO = new logindao();
	@Override
	public boolean checkUser(loginbean loginbean) {
		if(loginDAO.checkUser(loginbean)) {
			return true;
		}else {
		return false;
		}
	}
}

	
		
