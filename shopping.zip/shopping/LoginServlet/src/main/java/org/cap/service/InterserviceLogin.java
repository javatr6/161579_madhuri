package org.cap.service;

import org.cap.bean.loginbean;

public interface InterserviceLogin{

	public abstract boolean checkUser(loginbean loginBean);

	

}
